# JSORIA_GIT
Proyecto desarrollado en Laravel para la Corporacion J. Soria - Quillabamba - Cusco.

# DEVELOPERS
Cristian Castro Del Carpio (cristiancastrodc@gmail.com)
Bárbara Hari Galarreta Zuñiga (barbaragalarreta@gmail.com)